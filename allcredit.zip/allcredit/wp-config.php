<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://wordpress.org/support/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'allcredit' );

/** MySQL database username */
define( 'DB_USER', 'root' );

/** MySQL database password */
define( 'DB_PASSWORD', '' );

/** MySQL hostname */
define( 'DB_HOST', 'localhost' );

/** Database Charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The Database Collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         'MI}5mf`K4$ DF*W(61#|(UkH&%yi|YtmP.HHLcQc: V8YKX|4PP6o,3l-f0,`63t' );
define( 'SECURE_AUTH_KEY',  'V!`Lt{$={QfmbQz5j X1Z^83/5WFfZX/qr8Gi<!K%5/^ShmetqETnz-0!>q;LxvH' );
define( 'LOGGED_IN_KEY',    ':(p+6xRbyhv@={?O<jHpD?3$&6^1s,9=I66oB<+cmDewq $>DJVb@jTY6k/?CvW/' );
define( 'NONCE_KEY',        ';&BZ7EPEP?;#~B,1(JWc_sS;z[LED,I2gCN#/t^MwK(AN(SbyVQac:mXFmokH[UR' );
define( 'AUTH_SALT',        '.i f@BP,~l?yuC3H^x>{%xBP&)?hMj=iIG>LR^<h:se0a!Dmwh~K+0#`F867 o b' );
define( 'SECURE_AUTH_SALT', 'D)gU`b,RstW/w5vQ-(;mKG.POkQJX.T>j/:5cVyDqxb$Fw`Ox>$)$#RD7+SrmrV@' );
define( 'LOGGED_IN_SALT',   'y<(ZM@})FDyipCbun(WL}#9k$+L5%LAfMeKY@6r<_0vl7?$/s>-)8.< }-Q+5,i?' );
define( 'NONCE_SALT',       'Rh0<EC0CX%bj!p@t$*F![]<qKGE9e@>p<kQxtKdGv`+U0)^paF9`f4Oz@]#rm_vK' );

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/support/article/debugging-in-wordpress/
 */
define( 'WP_DEBUG', false );

/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
